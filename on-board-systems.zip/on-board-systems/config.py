# -*- coding: utf-8 -*-
"""Модуль конфигурации приложения"""

import configparser
import os

class Config:
    """Класс конфигурации"""
    
    def __init__(self, config_file='config.ini'):
        self.config = configparser.ConfigParser()
        config_path = os.path.join(os.path.dirname(__file__), config_file)
        self.config.read(config_path, encoding='utf-8')
    
    @property
    def database_path(self):
        return self.config.get('database', 'path', fallback='satellite.db')
    
    @property
    def database_type(self):
        return self.config.get('database', 'type', fallback='sqlite')
    
    @property
    def host(self):
        return self.config.get('server', 'host', fallback='127.0.0.1')
    
    @property
    def port(self):
        return self.config.getint('server', 'port', fallback=5000)
    
    @property
    def debug(self):
        return self.config.getboolean('server', 'debug', fallback=True)
    
    @property
    def secret_key(self):
        return self.config.get('security', 'secret_key', fallback='default-secret-key')

config = Config()
