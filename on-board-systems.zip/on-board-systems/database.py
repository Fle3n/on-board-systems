# -*- coding: utf-8 -*-
"""Модуль работы с базой данных"""

import sqlite3
import os
from datetime import datetime
from config import config

class Database:
    """Класс для работы с базой данных"""
    
    def __init__(self):
        self.db_path = os.path.join(os.path.dirname(__file__), config.database_path)
    
    def get_connection(self):
        """Получение соединения с БД"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_db(self):
        """Инициализация базы данных"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Таблица пользователей
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin', 'senior_engineer', 'junior_engineer')),
                full_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Таблица видов бортовых систем
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_types (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        """)
        
        # Таблица параметров для видов систем
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS type_parameters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                system_type_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                data_type TEXT DEFAULT 'text',
                unit TEXT,
                description TEXT,
                FOREIGN KEY (system_type_id) REFERENCES system_types(id) ON DELETE CASCADE
            )
        """)
        
        # Таблица экземпляров систем
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS systems (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                system_type_id INTEGER NOT NULL,
                serial_number TEXT UNIQUE NOT NULL,
                name TEXT,
                status TEXT DEFAULT 'created',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER,
                FOREIGN KEY (system_type_id) REFERENCES system_types(id),
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        """)
        
        # Таблица значений параметров для экземпляров
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS parameter_values (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                system_id INTEGER NOT NULL,
                parameter_id INTEGER NOT NULL,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by INTEGER,
                FOREIGN KEY (system_id) REFERENCES systems(id) ON DELETE CASCADE,
                FOREIGN KEY (parameter_id) REFERENCES type_parameters(id) ON DELETE CASCADE,
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        """)
        
        # Таблица событий
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                system_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                description TEXT NOT NULL,
                event_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER,
                FOREIGN KEY (system_id) REFERENCES systems(id) ON DELETE CASCADE,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        """)
        
        # Таблица журнала изменений параметров
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS parameter_changes_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                system_id INTEGER NOT NULL,
                parameter_id INTEGER NOT NULL,
                old_value TEXT,
                new_value TEXT,
                changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                changed_by INTEGER,
                FOREIGN KEY (system_id) REFERENCES systems(id),
                FOREIGN KEY (parameter_id) REFERENCES type_parameters(id),
                FOREIGN KEY (changed_by) REFERENCES users(id)
            )
        """)
        
        # Создание пользователей по умолчанию
        import hashlib
        
        default_users = [
            ('admin', hashlib.sha256('admin123'.encode()).hexdigest(), 'admin', 'Администратор системы'),
            ('senior', hashlib.sha256('senior123'.encode()).hexdigest(), 'senior_engineer', 'Старший инженер'),
            ('junior', hashlib.sha256('junior123'.encode()).hexdigest(), 'junior_engineer', 'Младший инженер')
        ]
        
        for user in default_users:
            try:
                cursor.execute(
                    "INSERT INTO users (username, password, role, full_name) VALUES (?, ?, ?, ?)",
                    user
                )
            except sqlite3.IntegrityError:
                pass
        
        conn.commit()
        conn.close()
        print("База данных инициализирована")
    
    # ==================== Методы для пользователей ====================
    
    def get_user(self, username):
        """Получение пользователя по имени"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()
        return user
    
    def get_user_by_id(self, user_id):
        """Получение пользователя по ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        conn.close()
        return user
    
    def get_all_users(self):
        """Получение всех пользователей"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users ORDER BY username")
        users = cursor.fetchall()
        conn.close()
        return users
    
    def add_user(self, username, password, role, full_name):
        """Добавление пользователя"""
        import hashlib
        conn = self.get_connection()
        cursor = conn.cursor()
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        cursor.execute(
            "INSERT INTO users (username, password, role, full_name) VALUES (?, ?, ?, ?)",
            (username, password_hash, role, full_name)
        )
        conn.commit()
        conn.close()
    
    def delete_user(self, user_id):
        """Удаление пользователя"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
    
    # ==================== Методы для видов систем ====================
    
    def add_system_type(self, name, description, parameters, user_id):
        """Добавление вида системы с параметрами"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO system_types (name, description, created_by) VALUES (?, ?, ?)",
            (name, description, user_id)
        )
        type_id = cursor.lastrowid
        
        for param in parameters:
            cursor.execute(
                "INSERT INTO type_parameters (system_type_id, name, data_type, unit, description) VALUES (?, ?, ?, ?, ?)",
                (type_id, param['name'], param.get('data_type', 'text'), 
                 param.get('unit', ''), param.get('description', ''))
            )
        
        conn.commit()
        conn.close()
        return type_id
    
    def get_all_system_types(self):
        """Получение всех видов систем"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM system_types ORDER BY name")
        types = cursor.fetchall()
        conn.close()
        return types
    
    def get_system_type(self, type_id):
        """Получение вида системы по ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM system_types WHERE id = ?", (type_id,))
        system_type = cursor.fetchone()
        conn.close()
        return system_type
    
    def get_type_parameters(self, type_id):
        """Получение параметров вида системы"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM type_parameters WHERE system_type_id = ?", (type_id,))
        params = cursor.fetchall()
        conn.close()
        return params
    
    def delete_system_type(self, type_id):
        """Удаление вида системы"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM system_types WHERE id = ?", (type_id,))
        conn.commit()
        conn.close()
    
    # ==================== Методы для экземпляров систем ====================
    
    def add_system(self, system_type_id, serial_number, name, notes, parameter_values, user_id):
        """Добавление экземпляра системы"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO systems (system_type_id, serial_number, name, notes, created_by) VALUES (?, ?, ?, ?, ?)",
            (system_type_id, serial_number, name, notes, user_id)
        )
        system_id = cursor.lastrowid
        
        for param_id, value in parameter_values.items():
            cursor.execute(
                "INSERT INTO parameter_values (system_id, parameter_id, value, updated_by) VALUES (?, ?, ?, ?)",
                (system_id, param_id, value, user_id)
            )
        
        # Добавляем событие создания
        cursor.execute(
            "INSERT INTO events (system_id, event_type, description, created_by) VALUES (?, ?, ?, ?)",
            (system_id, 'creation', 'Система создана в базе данных', user_id)
        )
        
        conn.commit()
        conn.close()
        return system_id
    
    def get_all_systems(self):
        """Получение всех систем"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, st.name as type_name, u.full_name as creator_name
            FROM systems s
            JOIN system_types st ON s.system_type_id = st.id
            LEFT JOIN users u ON s.created_by = u.id
            ORDER BY s.created_at DESC
        """)
        systems = cursor.fetchall()
        conn.close()
        return systems
    
    def get_system(self, system_id):
        """Получение системы по ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, st.name as type_name
            FROM systems s
            JOIN system_types st ON s.system_type_id = st.id
            WHERE s.id = ?
        """, (system_id,))
        system = cursor.fetchone()
        conn.close()
        return system
    
    def get_system_by_serial(self, serial_number):
        """Получение системы по серийному номеру"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, st.name as type_name
            FROM systems s
            JOIN system_types st ON s.system_type_id = st.id
            WHERE s.serial_number = ?
        """, (serial_number,))
        system = cursor.fetchone()
        conn.close()
        return system
    
    def search_systems(self, query):
        """Поиск систем"""
        conn = self.get_connection()
        cursor = conn.cursor()
        search_query = f"%{query}%"
        cursor.execute("""
            SELECT s.*, st.name as type_name
            FROM systems s
            JOIN system_types st ON s.system_type_id = st.id
            WHERE s.serial_number LIKE ? OR s.name LIKE ? OR st.name LIKE ?
            ORDER BY s.created_at DESC
        """, (search_query, search_query, search_query))
        systems = cursor.fetchall()
        conn.close()
        return systems
    
    def get_system_parameters(self, system_id):
        """Получение параметров экземпляра системы"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT pv.*, tp.name, tp.unit, tp.data_type, tp.description
            FROM parameter_values pv
            JOIN type_parameters tp ON pv.parameter_id = tp.id
            WHERE pv.system_id = ?
        """, (system_id,))
        params = cursor.fetchall()
        conn.close()
        return params
    
    def update_system(self, system_id, name, status, notes, parameter_values, user_id):
        """Обновление системы и её параметров"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Обновляем основную информацию
        cursor.execute(
            "UPDATE systems SET name = ?, status = ?, notes = ? WHERE id = ?",
            (name, status, notes, system_id)
        )
        
        # Обновляем параметры с логированием
        for param_id, new_value in parameter_values.items():
            # Получаем старое значение
            cursor.execute(
                "SELECT value FROM parameter_values WHERE system_id = ? AND parameter_id = ?",
                (system_id, param_id)
            )
            row = cursor.fetchone()
            old_value = row['value'] if row else None
            
            if old_value != new_value:
                # Логируем изменение
                cursor.execute(
                    """INSERT INTO parameter_changes_log 
                       (system_id, parameter_id, old_value, new_value, changed_by) 
                       VALUES (?, ?, ?, ?, ?)""",
                    (system_id, param_id, old_value, new_value, user_id)
                )
                
                # Обновляем значение
                if row:
                    cursor.execute(
                        "UPDATE parameter_values SET value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ? WHERE system_id = ? AND parameter_id = ?",
                        (new_value, user_id, system_id, param_id)
                    )
                else:
                    cursor.execute(
                        "INSERT INTO parameter_values (system_id, parameter_id, value, updated_by) VALUES (?, ?, ?, ?)",
                        (system_id, param_id, new_value, user_id)
                    )
        
        conn.commit()
        conn.close()
    
    def delete_system(self, system_id):
        """Удаление системы"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM systems WHERE id = ?", (system_id,))
        conn.commit()
        conn.close()
    
    # ==================== Методы для событий ====================
    
    def add_event(self, system_id, event_type, description, user_id):
        """Добавление события"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO events (system_id, event_type, description, created_by) VALUES (?, ?, ?, ?)",
            (system_id, event_type, description, user_id)
        )
        event_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return event_id
    
    def get_system_events(self, system_id):
        """Получение событий системы"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.*, u.full_name as creator_name
            FROM events e
            LEFT JOIN users u ON e.created_by = u.id
            WHERE e.system_id = ?
            ORDER BY e.event_date DESC
        """, (system_id,))
        events = cursor.fetchall()
        conn.close()
        return events
    
    def get_all_events(self):
        """Получение всех событий"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.*, s.serial_number, s.name as system_name, u.full_name as creator_name
            FROM events e
            JOIN systems s ON e.system_id = s.id
            LEFT JOIN users u ON e.created_by = u.id
            ORDER BY e.event_date DESC
            LIMIT 100
        """)
        events = cursor.fetchall()
        conn.close()
        return events
    
    # ==================== Методы для журнала изменений ====================
    
    def get_parameter_changes(self, system_id):
        """Получение истории изменений параметров"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT pcl.*, tp.name as parameter_name, u.full_name as changed_by_name
            FROM parameter_changes_log pcl
            JOIN type_parameters tp ON pcl.parameter_id = tp.id
            LEFT JOIN users u ON pcl.changed_by = u.id
            WHERE pcl.system_id = ?
            ORDER BY pcl.changed_at DESC
        """, (system_id,))
        changes = cursor.fetchall()
        conn.close()
        return changes


db = Database()
