#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Скрипт запуска приложения"""

from database import db
from app import app
from config import config

if __name__ == '__main__':
    # Инициализация базы данных
    db.init_db()
    
    print(f"\n{'='*50}")
    print("Система управления бортовыми системами спутника")
    print(f"{'='*50}")
    print(f"Сервер запущен: http://{config.host}:{config.port}")
    print(f"База данных: {config.database_path}")
    print("\nУчётные записи по умолчанию:")
    print("  admin / admin123 - Администратор")
    print("  senior / senior123 - Старший инженер")
    print("  junior / junior123 - Младший инженер")
    print(f"{'='*50}\n")
    
    # Запуск сервера
    app.run(host=config.host, port=config.port, debug=config.debug)
