# -*- coding: utf-8 -*-
"""Главный модуль приложения Flask"""

from flask import Flask, render_template, request, redirect, url_for, flash, session
from functools import wraps
import hashlib
from config import config
from database import db

app = Flask(__name__)
app.secret_key = config.secret_key

# ==================== Декораторы ====================

def login_required(f):
    """Декоратор для проверки авторизации"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Необходимо войти в систему', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(*roles):
    """Декоратор для проверки роли"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_role' not in session:
                flash('Необходимо войти в систему', 'error')
                return redirect(url_for('login'))
            if session['user_role'] not in roles:
                flash('Недостаточно прав для выполнения операции', 'error')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ==================== Контекст шаблонов ====================

@app.context_processor
def inject_user():
    """Добавление информации о пользователе в контекст шаблонов"""
    if 'user_id' in session:
        return {
            'current_user': {
                'id': session['user_id'],
                'username': session['username'],
                'role': session['user_role'],
                'full_name': session.get('full_name', '')
            }
        }
    return {'current_user': None}

# ==================== Аутентификация ====================

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Страница входа"""
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        user = db.get_user(username)
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        if user and user['password'] == password_hash:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['user_role'] = user['role']
            session['full_name'] = user['full_name']
            flash('Вход выполнен успешно', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Выход из системы"""
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))

# ==================== Главная страница ====================

@app.route('/')
@login_required
def index():
    """Главная страница"""
    systems = db.get_all_systems()
    recent_events = db.get_all_events()[:10]
    return render_template('index.html', systems=systems, recent_events=recent_events)

# ==================== Виды систем ====================

@app.route('/system-types')
@login_required
def system_types():
    """Список видов систем"""
    types = db.get_all_system_types()
    return render_template('system_types.html', system_types=types)

@app.route('/system-type/add', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'senior_engineer')
def add_system_type():
    """Добавление вида системы"""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        
        # Сбор параметров
        param_names = request.form.getlist('param_name[]')
        param_types = request.form.getlist('param_type[]')
        param_units = request.form.getlist('param_unit[]')
        param_descriptions = request.form.getlist('param_description[]')
        
        parameters = []
        for i in range(len(param_names)):
            if param_names[i].strip():
                parameters.append({
                    'name': param_names[i].strip(),
                    'data_type': param_types[i] if i < len(param_types) else 'text',
                    'unit': param_units[i] if i < len(param_units) else '',
                    'description': param_descriptions[i] if i < len(param_descriptions) else ''
                })
        
        if name:
            try:
                db.add_system_type(name, description, parameters, session['user_id'])
                flash('Вид системы успешно добавлен', 'success')
                return redirect(url_for('system_types'))
            except Exception as e:
                flash(f'Ошибка при добавлении: {str(e)}', 'error')
        else:
            flash('Название не может быть пустым', 'error')
    
    return render_template('add_system_type.html')

@app.route('/system-type/<int:type_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete_system_type(type_id):
    """Удаление вида системы"""
    try:
        db.delete_system_type(type_id)
        flash('Вид системы удалён', 'success')
    except Exception as e:
        flash(f'Ошибка при удалении: {str(e)}', 'error')
    return redirect(url_for('system_types'))

# ==================== Системы ====================

@app.route('/systems')
@login_required
def systems():
    """Список всех систем"""
    all_systems = db.get_all_systems()
    return render_template('systems.html', systems=all_systems)

@app.route('/system/add', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'senior_engineer')
def add_system():
    """Добавление системы"""
    system_types = db.get_all_system_types()
    
    if request.method == 'POST':
        system_type_id = request.form.get('system_type_id')
        serial_number = request.form.get('serial_number', '').strip()
        name = request.form.get('name', '').strip()
        notes = request.form.get('notes', '').strip()
        
        # Сбор значений параметров
        parameter_values = {}
        for key, value in request.form.items():
            if key.startswith('param_'):
                param_id = key.replace('param_', '')
                parameter_values[param_id] = value
        
        if serial_number and system_type_id:
            try:
                system_id = db.add_system(
                    system_type_id, serial_number, name, notes, 
                    parameter_values, session['user_id']
                )
                flash('Система успешно добавлена', 'success')
                return redirect(url_for('system_detail', system_id=system_id))
            except Exception as e:
                flash(f'Ошибка при добавлении: {str(e)}', 'error')
        else:
            flash('Заполните обязательные поля', 'error')
    
    # Получение параметров для выбранного типа (AJAX)
    selected_type_id = request.args.get('type_id')
    type_parameters = []
    if selected_type_id:
        type_parameters = db.get_type_parameters(selected_type_id)
    
    return render_template('add_system.html', 
                          system_types=system_types, 
                          type_parameters=type_parameters,
                          selected_type_id=selected_type_id)

@app.route('/system/<int:system_id>')
@login_required
def system_detail(system_id):
    """Детальная информация о системе"""
    system = db.get_system(system_id)
    if not system:
        flash('Система не найдена', 'error')
        return redirect(url_for('systems'))
    
    parameters = db.get_system_parameters(system_id)
    events = db.get_system_events(system_id)
    changes = db.get_parameter_changes(system_id)
    
    return render_template('system_detail.html', 
                          system=system, 
                          parameters=parameters,
                          events=events,
                          changes=changes)

@app.route('/system/<int:system_id>/edit', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'senior_engineer')
def edit_system(system_id):
    """Редактирование системы"""
    system = db.get_system(system_id)
    if not system:
        flash('Система не найдена', 'error')
        return redirect(url_for('systems'))
    
    type_parameters = db.get_type_parameters(system['system_type_id'])
    current_values = {str(p['parameter_id']): p['value'] for p in db.get_system_parameters(system_id)}
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        status = request.form.get('status', '')
        notes = request.form.get('notes', '').strip()
        
        parameter_values = {}
        for key, value in request.form.items():
            if key.startswith('param_'):
                param_id = key.replace('param_', '')
                parameter_values[param_id] = value
        
        try:
            db.update_system(system_id, name, status, notes, parameter_values, session['user_id'])
            flash('Система обновлена', 'success')
            return redirect(url_for('system_detail', system_id=system_id))
        except Exception as e:
            flash(f'Ошибка при обновлении: {str(e)}', 'error')
    
    return render_template('edit_system.html', 
                          system=system, 
                          type_parameters=type_parameters,
                          current_values=current_values)

@app.route('/system/<int:system_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete_system(system_id):
    """Удаление системы"""
    try:
        db.delete_system(system_id)
        flash('Система удалена', 'success')
    except Exception as e:
        flash(f'Ошибка при удалении: {str(e)}', 'error')
    return redirect(url_for('systems'))

# ==================== Поиск ====================

@app.route('/search')
@login_required
def search():
    """Поиск систем"""
    query = request.args.get('q', '').strip()
    results = []
    if query:
        results = db.search_systems(query)
    return render_template('search.html', query=query, results=results)

# ==================== События ====================

@app.route('/system/<int:system_id>/event/add', methods=['GET', 'POST'])
@login_required
def add_event(system_id):
    """Добавление события"""
    system = db.get_system(system_id)
    if not system:
        flash('Система не найдена', 'error')
        return redirect(url_for('systems'))
    
    if request.method == 'POST':
        event_type = request.form.get('event_type', '').strip()
        description = request.form.get('description', '').strip()
        
        if event_type and description:
            try:
                db.add_event(system_id, event_type, description, session['user_id'])
                flash('Событие добавлено', 'success')
                return redirect(url_for('system_detail', system_id=system_id))
            except Exception as e:
                flash(f'Ошибка при добавлении: {str(e)}', 'error')
        else:
            flash('Заполните все поля', 'error')
    
    return render_template('add_event.html', system=system)

@app.route('/events')
@login_required
def events():
    """Список всех событий"""
    all_events = db.get_all_events()
    return render_template('events.html', events=all_events)

# ==================== Администрирование ====================

@app.route('/admin')
@login_required
@role_required('admin')
def admin():
    """Панель администратора"""
    users = db.get_all_users()
    return render_template('admin.html', users=users)

@app.route('/admin/user/add', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def add_user():
    """Добавление пользователя"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        role = request.form.get('role', '')
        full_name = request.form.get('full_name', '').strip()
        
        if username and password and role:
            try:
                db.add_user(username, password, role, full_name)
                flash('Пользователь добавлен', 'success')
                return redirect(url_for('admin'))
            except Exception as e:
                flash(f'Ошибка: {str(e)}', 'error')
        else:
            flash('Заполните все обязательные поля', 'error')
    
    return render_template('add_user.html')

@app.route('/admin/user/<int:user_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete_user(user_id):
    """Удаление пользователя"""
    if user_id == session['user_id']:
        flash('Нельзя удалить самого себя', 'error')
    else:
        try:
            db.delete_user(user_id)
            flash('Пользователь удалён', 'success')
        except Exception as e:
            flash(f'Ошибка: {str(e)}', 'error')
    return redirect(url_for('admin'))

# ==================== API для AJAX ====================

@app.route('/api/type-parameters/<int:type_id>')
@login_required
def api_type_parameters(type_id):
    """API для получения параметров типа системы"""
    parameters = db.get_type_parameters(type_id)
    return {
        'parameters': [
            {
                'id': p['id'],
                'name': p['name'],
                'data_type': p['data_type'],
                'unit': p['unit'],
                'description': p['description']
            } for p in parameters
        ]
    }

# ==================== Запуск приложения ====================

if __name__ == '__main__':
    db.init_db()
    app.run(host=config.host, port=config.port, debug=config.debug)
